#!/bin/bash
echo "========================================================"
echo "        APEX OFFICE - SUITE OFIMATICA SOBERANA"
echo "========================================================"
PORT=48123
echo "Iniciando servidor local en http://localhost:$PORT..."
if command -v python3 &>/dev/null; then
    python3 -m http.server $PORT &
elif command -v python &>/dev/null; then
    python -m SimpleHTTPServer $PORT &
elif command -v php &>/dev/null; then
    php -S localhost:$PORT &
fi

if command -v xdg-open &>/dev/null; then
    xdg-open "http://localhost:$PORT" 2>/dev/null
elif command -v open &>/dev/null; then
    open "http://localhost:$PORT" 2>/dev/null
fi
wait
