@echo off
title Apex Office - Lanzador Portable
echo ========================================================
echo         APEX OFFICE - SUITE OFIMATICA SOBERANA
echo ========================================================
echo Iniciando servidor local ultraligero...
powershell.exe -ExecutionPolicy Bypass -NoProfile -Command "$listener = New-Object System.Net.HttpListener; $port = 48123; $listener.Prefixes.Add('http://localhost:' + $port + '/'); $listener.Start(); Start-Process ('http://localhost:' + $port + '/'); Write-Host 'Apex Office ejecutandose en http://localhost:' $port; Write-Host 'Presiona Ctrl+C o cierra esta ventana para salir.'; while ($listener.IsListening) { $ctx = $listener.GetContext(); $req = $ctx.Request; $res = $ctx.Response; $rel = $req.Url.LocalPath.TrimStart('/'); if ([string]::IsNullOrEmpty($rel)) { $rel = 'index.html' }; $filePath = Join-Path (Get-Location) $rel; if (Test-Path $filePath -PathType Leaf) { $bytes = [System.IO.File]::ReadAllBytes($filePath); $ext = [System.IO.Path]::GetExtension($filePath).ToLower(); switch ($ext) { '.html' { $res.ContentType = 'text/html; charset=utf-8' } '.js' { $res.ContentType = 'application/javascript; charset=utf-8' } '.css' { $res.ContentType = 'text/css; charset=utf-8' } '.json' { $res.ContentType = 'application/json' } '.svg' { $res.ContentType = 'image/svg+xml' } '.png' { $res.ContentType = 'image/png' } default { $res.ContentType = 'application/octet-stream' } }; $res.ContentLength64 = $bytes.Length; $res.OutputStream.Write($bytes, 0, $bytes.Length) } else { $res.StatusCode = 404 }; $res.Close() }"
pause
